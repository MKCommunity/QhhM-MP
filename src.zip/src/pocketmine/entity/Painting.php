<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____  
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \ 
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/ 
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_| 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 * 
 *
*/

namespace pocketmine\entity;


use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AddPaintingPacket;
use pocketmine\item\Item as ItemItem;
use pocketmine\Player;
use pocketmine\level\particle\DestroyBlockParticle;
use pocketmine\block\Block;

class Painting extends Hanging{

	const NETWORK_ID = 83;

	private $motive;

	public function initEntity(){
		$this->setMaxHealth(1);

		parent::initEntity();

		if(isset($this->namedtag->Motive)){
			$this->motive = $this->namedtag["Motive"];
		}else{
			$this->close();
		}
	}

	public function attack(EntityDamageEvent $source){
		parent::attack($source);
		if($source->isCancelled()) return false;
		$this->level->addParticle(new DestroyBlockParticle($this->add(0.5), Block::get(Block::LADDER)));

		$this->kill();
	}

	public function spawnTo(Player $player){
		$pk = new AddPaintingPacket();
		$pk->entityRuntimeId = $this->getId();
	
		$pk->position = $this->asVector3();

		$pk->direction = $this->getDirection();
		$pk->title = $this->motive;
		$player->dataPacket($pk);

		parent::spawnTo($player);
	}

	protected function updateMovement(){
	}

	public function getDrops() : array{
		return [ItemItem::get(ItemItem::PAINTING, 0, 1)];
	}
}